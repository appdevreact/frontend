import React from "react";
import logo from "./logo.svg";
import EmployeeContainer from "./components/student/EmployeeContainer";

import "./App.css";

export const App = () => {
  return (
    <div>
      <EmployeeContainer />
    </div>
  );
};

export default App;
