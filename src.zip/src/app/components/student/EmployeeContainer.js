import React, { Component } from "react";
import { connect } from "react-redux";
import { fetchEmployees } from "./employee-actions";
export class EmployeeContainer extends Component {
  componentDidMount() {
    this.props.fetchEmployees();
  }

  render() {
    const { data } = this.props;
    console.log(">>>>>>>Sunitha Data>>>>>>>>", data);
    return (
      <div>
        <table style={{ width: "120%" }}>
          <th>
            <tr>
              <th>ID</th>
              <th>ID</th>
              <th>ID</th>
              <th>ID</th>
              <th>ID</th>
              <th>ID</th>
            </tr>
          </th>

          {data.map(input => (
            <div>
              <p>{input.id}</p>
            </div>
          ))}
        </table>
      </div>
    );
  }
}
export const mapStateToProps = state => ({
  data: state.employeeInformation.data.data.data
});
export const mapDispatchToProps = {
  fetchEmployees
};
export default connect(mapStateToProps, mapDispatchToProps)(EmployeeContainer);
