import { fetchCommon } from "../../services/api";
export const STANDING_ORDERS_DATA = "STANDING_ORDERS_DATA";
// return fetchCommon()(dispatch, STANDING_ORDERS_DATA);
export const fetchEmployees = paras => (dispatch, getState) => {
  return fetchCommon('http://dummy.restapiexample.com/api/v1/employees')(dispatch, STANDING_ORDERS_DATA);
};
