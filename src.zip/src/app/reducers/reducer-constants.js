/**********************************
 *      Action and Reducer keys
 * ********************************/
export const getActionTypes = actionKey => {
  return {
    FETCHING: `${actionKey}_fetching`,
    FULFILLED: `${actionKey}_fulfilled`,
    REJECTED: `${actionKey}_rejected`
  };
};

// API related actions
export const STANDING_ORDERS_DATA = "STANDING_ORDERS_DATA";
export const ACTION_KEY_SUBMIT_CREDIT_ACCOUNT = "submit_credit_account";
export const ACTION_KEY_PRODUCT_LIST = "fetch_product_list";
export const ACTION_KEY_REFERENCES_LIST = "fetch_references_list";
export const ACTION_KEY_INTEREST_RATE_LIST = "fetch_interest_rate_list";
export const ACTION_KEY_OTHER_RATE_LIST = "fetch_other_rate_list";
export const ACTION_KEY_FETCH_DROPDOWNS = "fetch_dropdowns";
export const ACTION_KEY_APPROVAL_DETAILS = "fetch_approval_details";
export const ACTION_KEY_GET_CREDIT_CARD_NUMBER = "fetch_credit_card_number";
export const ACTION_KEY_CREDIT_SEARCH = "fetch_credit_search";
export const ACTION_KEY_CREDIT_ACCOUNT = "fetch_credit_account";
export const ACTION_KEY_TRANSACTIONS_HISTORY = "fetch_transactions_history";
export const ACTION_KEY_DECREASE_LIMIT = "fetch_decrease_limit";
export const ACTION_KEY_TRANSACTIONS_PAGINATION =
  "fetch_transactions_pagination";
export const ACTION_KEY_PENDING_TRANSACTIONS_HISTORY =
  "fetch_pending_transactions_history";
export const ACTION_KEY_PENDING_TRANSACTIONS_PAGINATION =
  "fetch_pending_transactions_pagination";
export const ACTION_KEY_REWARDS = "fetch_rewards";
export const ACTION_KEY_GET_SECURITY_LEVELS = "fetch_security_levels";

// User actions
export const SAVE_SELECTED_PRODUCT_TYPE = "save_selected_product_type";
export const SAVE_CUSTOMER_REFERENCES_TO_MODEL =
  "save_customer_references_to_model";
export const UPDATE_INTEREST_PRODUCT = "update_interest_product";
export const SET_JWT_AND_QUERY_PARAMS = "set_jwt_and_query_params";
export const UPDATE_FORM_STATE = "update_final_form_state";
export const UPDATE_SIDEBAR = "update_sidebar";
export const SAVE_TRANSACTION_FILTER = "save_transaction_filter";
export const CLEAR_TRANSACTION_DATES = "clear_transaction_dates";
export const CLEAR_ALL_TRANSACTION_FILTERS = "clear_all_transaction_filters";
export const CLEAR_POSTED_TRANSACTIONS_HISTORY =
  "clear_posted_transaction_history";
export const CLEAR_PENDING_TRANSACTIONS_HISTORY =
  "clear_pending_transaction_history";

// Credit Accounts Model
export const SAVE_SELECTED_OTHER_DETAILS = "save_selected_other_details";
export const UPDATE_SECURITY_DETAILS = "update_security_details";
export const UPDATE_SECURITY_AMOUNT = "update_security_amount";
export const UPDATE_CREDIT_ACCOUNT_FIELD = "update_credit_account_field";
export const UPDATE_PROTECTION_PRODUCT = "update_protection_product_list";
export const UPDATE_CARD_DETAIL_IDENTIFIER = "update_card_detail_identifier";
export const UPDATE_CREDIT_ACCOUNT_MONEY_AMOUNT =
  "update_credit_account_money_amount";
export const SETUP_CREDIT_CARD = "setup_credit_card";

//SECURITY REAL ESTATE
export const UPDATE_SECURITY_APPRAISED_VALUE =
  "update_security_appraised_value";
export const UPDATE_SECURITY_ACCOUNT_PURCHASE_PRICE =
  "update_security_purchase_price";
export const UPDATE_SECURITY_ACCOUNT_ANNUAL_TAX = "update_security_annual_tax";
export const UPDATE_SECURITY_ACCOUNT_CONDOMINIUM_FEES =
  "update_security_condominium_fees";
export const UPDATE_SECURITY_ACCOUNT_INSURANCE_AMOUNT =
  "update_security_insurance_amount";
export const UPDATE_SECURITY_ACCOUNT_LOAN_AMOUNT =
  "update_security_loan_amount";
export const UPDATE_SECURITY_ACCOUNT_DEDUCTIBLE = "update_security_deductible";
export const UPDATE_SECURITY_ACCOUNT_PREMIUM = "update_security_premium";
export const UPDATE_SECURITY_ACCOUNT_BANK_PAID_INSURANCE =
  "update_security_bank_paid_insurance";
export const UPDATE_SECURITY_REAL_ESTATE_RADIO_BUTTON_FIELD =
  "update_security_real_estate_radio_button";

//STATEMENTS ACTION
export const STATEMENTS_DATA = "STATEMENTS_DATA";
export const CLEAR_STATEMENTS_DATA = "CLEAR_STATEMENTS_DATA";
