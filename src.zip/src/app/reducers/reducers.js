import employeeInformation from "./employee-information";
export const reducers = {
  //Global ErrorF

  employeeInformation
};
